from django.apps import AppConfig


class HrapplicationsConfig(AppConfig):
    name = 'hrapplications'
